module.exports = {
    NAME_LAMBDA : "COSTUMER",
    ERROR_CUSTOMER_CREATED:"ConditionalCheckFailedException"
}